# /∗
# ∗ CSCI3180 Principles of Programming Languages
# ∗
# ∗ --- Declaration ---
# ∗
# ∗ I declare that the assignment here submitted is original except for source
# ∗ material explicitly acknowledged. I also acknowledge that I am aware of
# ∗ University policy and regulations on honesty in academic work, and of the
# ∗ disciplinary guidelines and procedures applicable to breaches of such policy
# ∗ and regulations, as contained in the website
# ∗ http://www.cuhk.edu.hk/policy/academichonesty/
# ∗
# ∗ Assignment 3
# ∗ Name : GAO Ming Yuan
# ∗ Student ID : 1155107738
# ∗ Email Addr : mygao8@cse.cuhk.edu.hk
# ∗/

use strict;
use warnings;
 
package Player;
sub new {
    my $class = shift @_;
    my @cards = (); # empty before passing in (from Deck.pm)
    my $self = {
        "name" => shift @_,
        "cards" =>  \@cards,
    };
    return bless $self, $class;
}

sub getCards {
    my $self = shift @_;
    my $cards = $self->{"cards"};
    my $taken = shift @_; # $taken is ref to array of the taken cards

    for (my $i = 0; $i <= $#$taken; $i = $i + 1) {
        push (@$cards, @$taken[$i]);
    };
}

sub dealCards {
    my $self = shift @_;
    my $cards = $self->{"cards"};  
    my $top = shift @$cards;

    # deal $top to game
    return $top;
}

sub numCards {
    my $self = shift @_;
    my $cards = $self->{"cards"};  
    my $size = @$cards;
    return $size;
}

return 1;